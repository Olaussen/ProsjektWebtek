//---------- NAVBAR ----------
const logo = document.getElementById('logo');
const site = window.location.href;
const menuButton = document.getElementById('menu_link');
const img = document.getElementById('menu_icon');

document.getElementById("resContent").style.minHeight = '600px';



/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function setIcon() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}

//Changes the menu-bar-image on hover
menuButton.onmouseout = function() {
  img.src = 'images/burger-menu-bars.png';
};
menuButton.onmouseover = function() {
  img.src = 'images/burger-menu-bars-hover.png';
};



//----------------------------
 /* Open or close reservation form*/
 function openForm() {
  document.getElementById("myRes").style.display = "block";
}
function closeForm() {
  document.getElementById("myRes").style.display = "none";
}
 /* Set min date to today*/
var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1;
var yyyy = today.getFullYear();
  if (dd < 10) {
    dd = '0' + dd
  }
  if (mm < 10) {
    mm = '0' + mm
  }
today = yyyy + '-' + mm + '-' + dd;
var maxy = yyyy + 1;
var max = maxy + "-" + mm + "-" + dd;
document.getElementById("dateinput").setAttribute("min", today);
document.getElementById("dateinput").setAttribute("value", today);
document.getElementById("dateinput").setAttribute("max", max);
 /* Set time */
 var now = new Date();
var hrs = now.getHours();
var min = now.getMinutes();
  if (hrs < 10) {
    hrs = "0" + hrs
  }
  if (min < 10) {
    min = "0" + min
  }
now = hrs + ":" + min;
document.getElementById("time").setAttribute("value", now);


/*--------Language script--------*/
function changelang_no_en(){
  if(window.location.pathname.slice(-12) == "bordres.html"){
    window.location.assign(window.location.pathname.slice(0, -12) + "bordres_eng.html");
  }
  if(window.location.pathname.slice(-10) == "about.html"){
    window.location.assign(window.location.pathname.slice(0, -10) + "about_eng.html");
  }
  if(window.location.pathname.slice(-9) == "meny.html"){
    window.location.assign(window.location.pathname.slice(0, -9) + "meny_eng.html");
  }
  if(window.location.pathname.slice(-12) == "galleri.html"){
    window.location.assign(window.location.pathname.slice(0, -12) + "galleri_eng.html");
  }
}
function changelang_en_no(){
  if(window.location.pathname.slice(-16) == "bordres_eng.html"){
    window.location.assign(window.location.pathname.slice(0, -16) + "bordres.html");
  }
  if(window.location.pathname.slice(-14) == "about_eng.html"){
    window.location.assign(window.location.pathname.slice(0, -14) + "about.html");
  }
  if(window.location.pathname.slice(-13) == "meny_eng.html"){
    window.location.assign(window.location.pathname.slice(0, -13) + "meny.html");
  }
  if(window.location.pathname.slice(-16) == "galleri_eng.html"){
    window.location.assign(window.location.pathname.slice(0, -16) + "galleri.html");
  }
}
